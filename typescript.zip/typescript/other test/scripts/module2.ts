//type: boolean, number, string, array, tuple, enum, any, void, null or undefined OR
// Variable var and let

enum gender {
    "male" = 1,
    "female"=2
}
let mygender: gender = 1;


class person {
    public gender: gender;
    public name: string;
    public age: number;
}

class IdigaoStaffMemeber extends person {
    constructor() {
        super();
    }
}

interface shape2D {
    height: number;
    width: number;
}

class Shapes implements shape2D {

   constructor(public height:number, public width:number) {

   }

   Perimerter():number {
       return (this.height + this.width)*2
   }

}
//parametre optionel
class triangle extends Shapes {

}

var r = new triangle(2, 3);
console.log(r.Perimerter());

//LET ET VAR
//if (true) {
//    let b = 1;
//}

//console.log(b);

//Var of et var in

var arr: string[];


arr = ["a", "b", "c"];
for (var item in arr) {
    console.log(item);
}

//ES5 et ES6
for (var item of arr) {
    console.log(item);
}

//generics
function mafonction<T>(arg:T):T {

    return arg;
}

console.log(mafonction("ram"));

//ajout de jquery
// et montrer affichage sur googlechrome