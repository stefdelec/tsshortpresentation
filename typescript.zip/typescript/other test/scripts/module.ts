 namespace Shapes {  
    export class Rectangle {
        constructor (
            public height: number, 
            public width: number) {
    }
    }
    // This works!
    var rect1 = new Rectangle(10, 4);
}

