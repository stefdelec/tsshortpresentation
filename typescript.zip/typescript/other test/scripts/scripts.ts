/// <reference path="module.ts" />
/// <reference path="jquery.d.ts" />

let myshapes:Shapes.Rectangle;

myshapes=new Shapes.Rectangle(1,2);
var sha:Shapes.Rectangle=new Shapes.Rectangle(2,3);

var arr:string[] = ["a", "b", "c"];
var arr2:Array<string>=["a", "b", "c"];

for (var item of arr) {
    console.log(item);
}

console.log(myshapes.height)

var template :any=$("#mytemplate").html(myshapes.height.toString());
//var template = $('#template').html();
//  var rendered = Mustache.render(template, {array:IdigaoStaff});
 // $('#target').html(rendered);

