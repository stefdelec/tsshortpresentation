var Shapes;
(function (Shapes) {
    var Rectangle = (function () {
        function Rectangle(height, width) {
            this.height = height;
            this.width = width;
        }
        return Rectangle;
    }());
    Shapes.Rectangle = Rectangle;
    // This works!
    var rect1 = new Rectangle(10, 4);
})(Shapes || (Shapes = {}));
/// <reference path="module.ts" />
/// <reference path="jquery.d.ts" />
var myshapes;
myshapes = new Shapes.Rectangle(1, 2);
var arr = ["a", "b", "c"];
var arr2 = ["a", "b", "c"];
for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
    var item = arr_1[_i];
    console.log(item);
}
console.log(myshapes.height);
var template = $("#mytemplate").html(myshapes.height.toLocaleString());

var shap=new Shapes.Rectangle("rec","tintin");
console.log(shap.height);
//var template = $('#template').html();
//  var rendered = Mustache.render(template, {array:IdigaoStaff});
// $('#target').html(rendered);
//# sourceMappingURL=main.js.map