var myvar: number = 3;
var boo: boolean = true;
var string: string = "je suis un string";
var variable: any;
var arraystring: Array<string>;

enum gender {
    "male" = 1,
    "female" = 2
}

var idiexample = new IdiRh.IdigaoStffMember(1, "Claude", "CEO");

var arr: string[] = ["a", "b", "c"];
for (var item in arr) {
    console.log(item);
}

for (var item of arr) {
    console.log(item);
}

namespace IdiRh {
    interface human {
        gender: gender;

    }
    interface name {
        name: string;
    }
    class humanbeing implements human, name {
        public gender: gender;
        public name: string;
        private age: number;
        constructor(gender: gender, name: string) {
            this.gender = gender;
            this.name = name;
        }
    }
  export  class IdigaoStffMember extends humanbeing {
        public position: string;
        constructor(gender: gender, name: string, position?: string) {
            super(gender, name, )
            this.position = position;
        }
        Getname(): string {
            return this.name;
        }
        Add(n:number,m:number){
            return n+m;
        }
    }
}

