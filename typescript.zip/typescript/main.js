var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
// 
var myvar = 3;
var boo = true;
var string = "je suis un string";
var variable;
var arraystring;
var gender;
(function (gender) {
    gender[gender["male"] = 1] = "male";
    gender[gender["female"] = 2] = "female";
})(gender || (gender = {}));
var idiexample = new IdiRh.IdigaoStffMember(1, "Claude", "CEO");
var arr = ["a", "b", "c"];
for (var item in arr) {
    console.log(item);
}
for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
    var item = arr_1[_i];
    console.log(item);
}
var IdiRh;
(function (IdiRh) {
    var humanbeing = (function () {
        function humanbeing(gender, name) {
            this.gender = gender;
            this.name = name;
        }
        return humanbeing;
    }());
    var IdigaoStffMember = (function (_super) {
        __extends(IdigaoStffMember, _super);
        function IdigaoStffMember(gender, name, position) {
            _super.call(this, gender, name);
            this.position = position;
        }
        IdigaoStffMember.prototype.Getname = function () {
            return this.name;
        };
        IdigaoStffMember.prototype.Add = function (n, m) {
            return n + m;
        };
        return IdigaoStffMember;
    }(humanbeing));
    IdiRh.IdigaoStffMember = IdigaoStffMember;
})(IdiRh || (IdiRh = {}));

